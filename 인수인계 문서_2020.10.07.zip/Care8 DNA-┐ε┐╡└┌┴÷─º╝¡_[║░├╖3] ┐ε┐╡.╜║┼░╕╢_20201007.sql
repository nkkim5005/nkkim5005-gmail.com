

-- 테이블 care8-prod.t_accessible_menu 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_accessible_menu` (
  `MENU_ID` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '메뉴ID',
  `MANAGER_GROUP_ID` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '메니저 그룹 ID'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_app_extra_service_statistic 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_app_extra_service_statistic` (
  `TR_DATE` varchar(8) NOT NULL COMMENT '거래 날짜',
  `AGE` int(11) NOT NULL DEFAULT '0' COMMENT '나이대',
  `TEMP_MALE_CNT` int(11) DEFAULT '0' COMMENT '신청상품 남자 가입자수',
  `TEMP_FEMALE_CNT` int(11) DEFAULT '0' COMMENT '신청상품 여자 가입자수',
  `TEMP_CNT` int(11) DEFAULT '0' COMMENT '신청상품 가입자수',
  `SIGNUP_FEMALE_CNT` int(11) DEFAULT '0' COMMENT '본상품 여자 가입자수',
  `SIGNUP_MALE_CNT` int(11) DEFAULT '0' COMMENT '본상품 남자 가입자수',
  `SIGNUP_CNT` int(11) DEFAULT '0' COMMENT '본상품 수',
  `TEMP_EXPIRE_MALE_CNT` int(11) DEFAULT '0' COMMENT '신청상품 남자 탈퇴수',
  `TEMP_EXPIRE_FEMALE_CNT` int(11) DEFAULT '0' COMMENT '신청상품 여자 탈퇴수',
  `TEMP_EXPRIE_CNT` int(11) DEFAULT '0' COMMENT '신청사품 탈퇴수',
  `SIGNUP_EXPIRE_MALE_CNT` int(11) DEFAULT '0' COMMENT '본상품 탈퇴 남자수',
  `SIGNUP_EXPIRE_FEMALE_CNT` int(11) DEFAULT '0' COMMENT '본상품 탈퇴 여자수',
  `SIGNUP_EXPIRE_CNT` int(11) DEFAULT '0' COMMENT '본상품 탈퇴수',
  `INSERT_DATE` datetime DEFAULT NULL COMMENT '추가 날짜'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_app_signup_expire_statistic 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_app_signup_expire_statistic` (
  `TR_DATE` varchar(8) DEFAULT NULL COMMENT '처리일',
  `AGE` int(11) DEFAULT NULL COMMENT '나이대',
  `SIGNUP_USER_CNT` int(11) DEFAULT NULL COMMENT '가입 사용자 수',
  `SIGNUP_FEMALE_CNT` int(11) DEFAULT NULL COMMENT '여자 가입자 수',
  `SIGNUP_MALE_CNT` int(11) DEFAULT NULL COMMENT '남자 사용자수',
  `EXPIRE_USER_CNT` int(11) DEFAULT NULL COMMENT '탙퇴 사용자수',
  `EXPIRE_FEMALE_CNT` int(11) DEFAULT NULL COMMENT '여자 탈퇴 수',
  `EXPIRE_MALE_CNT` int(11) DEFAULT NULL COMMENT '남자 탈퇴수',
  `INSERT_DATE` datetime DEFAULT NULL COMMENT '추가 시간'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='회원 가입/탈퇴 통계';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_common 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_common` (
  `COMMON_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '코드 INDEX',
  `CODE_ID` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '코드 ID',
  `CODE_NAME` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '코드 이름',
  `CODE_DTL_ID` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '코드 상세 ID',
  `CODE_DTL_NAME` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '코드 상세 이름',
  `P_CODE_ID` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '부모 코드 INDEX',
  `ORDERBY` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '정렬 순서',
  `DEL_YN` char(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT '삭제 여부',
  PRIMARY KEY (`COMMON_IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=126 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_consulting 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_consulting` (
  `CONSULTING_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '상담INDEX',
  `USER_IDX` int(11) NOT NULL,
  `CATEGORY` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '상담 유형\r\nNUTRIENT: 영향\r\nSPORT: 운동\r\nRESULT:검사 결과',
  `STATUS` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'READY: 대기\r\nPROGRESS: 진행\r\nCOMPLETE: 완료',
  `TITLE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '제목',
  `CONTENTS` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '내용',
  `ANSWER` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '답변',
  `ANSWER_INSERT_DATE` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '날변날짜',
  `Q_FILE_GROUP_IDX` int(11) NOT NULL COMMENT '질문 파일 그룹 IDX',
  `A_FILE_GROUP_IDX` int(11) DEFAULT NULL COMMENT '답변 파일 그룹 IDX',
  `DEL_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT '삭제 여부',
  `MANAGER_IDX` int(11) DEFAULT NULL COMMENT '관리자 IDX',
  `BADGE_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT '뱃지 YN',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '업데이트 날짜',
  `INSERT_DATE` datetime DEFAULT NULL COMMENT '추가 날짜',
  PRIMARY KEY (`CONSULTING_IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_coupon 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_coupon` (
  `COUPON_CODE` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `COUPON_TYPE` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '상담쿠폰:CNSLT, MIND7:작심7일, 제휴쿠폰:ALLY',
  `ISSUE_TYPE` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '정기발행:REGULAR, 추가발행:CONSULT, 작심7일:MIND7, 이벤트:EVENT',
  `STATUS` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '사용전:BEFORE, 사용후:AFTER, 기간만료:EXPIRE',
  `OWNER_ID` int(11) DEFAULT NULL COMMENT '소유자 IDX',
  `AVAILABLE_START_DATE` datetime DEFAULT NULL COMMENT '사용가능 시작 날짜',
  `AVAILABLE_END_DATE` datetime DEFAULT NULL COMMENT '사용가능 종료 날짜',
  `CONSUME_WHERE` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '(사용)상담쿠폰일 경우 CONSULTING_IDX',
  `ISSUE_IDX` int(11) DEFAULT NULL COMMENT '(발급)발급자/이벤트명',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '업데이트 날짜',
  `INSERT_DATE` datetime DEFAULT NULL COMMENT '추가 날짜',
  PRIMARY KEY (`COUPON_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_coupon_issue_cnt 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_coupon_issue_cnt` (
  `ISSUE_CNT` int(11) DEFAULT NULL COMMENT '발행 갯수',
  `INSERT_DATE` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '추가 날짜'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='쿠폰 발급 갯수';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_cspcon_customer 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_cspcon_customer` (
  `SVC_MGMT_NUM` char(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '서비스관리번호',
  `CUST_NM` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '고객명',
  `SSN_BIRTH_DT` char(8) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '주민번호 추출 생년월일',
  `SSN_SEX_CD` char(1) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '주민번호 추출 성별구분',
  `SVC_NUM` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '서비스 번호 ( D1 인경우 업데이트해야함 부가서비스 조회 해당번호로)',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '업데이트 일자',
  `INSERT_DATE` datetime NOT NULL COMMENT '등록일자',
  PRIMARY KEY (`SVC_MGMT_NUM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='SKT_CSPCON 연동 서비스 정보 : SIMDG00001';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_cspcon_customer_additional 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_cspcon_customer_additional` (
  `SVC_MGMT_NUM` char(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SVC_MGMT_NUM',
  `PROD_ID` char(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '부가서비스코드',
  `JOIN_YN` char(1) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '부가서비스가입여부 (Y/N)',
  `JOIN_DT` datetime DEFAULT NULL COMMENT '부가서비스 가입 년월일',
  `CANCEL_DATE` datetime DEFAULT NULL COMMENT '해지일자',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '업데이트 일자',
  `INSERT_DATE` datetime NOT NULL COMMENT '등록일자',
  PRIMARY KEY (`SVC_MGMT_NUM`,`PROD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='SKT_CSPCON 연동 부가서비스 가입 여부 : SIMDG00003';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_cspcon_message 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_cspcon_message` (
  `MSG_ID` varchar(24) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '메시지ID',
  `SVC_MGMT_NUM` char(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '서비스관리번호',
  `MDN` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'MDN번호',
  `MIN` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'MIN번호',
  `NEW_MDN` varchar(11) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '신규MDN번호',
  `NEW_MIN` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '신규MIN번호',
  `SVC_FLAG` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '서비스업무코드',
  `PROD_ID` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '부가서비스ID',
  `ETC` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '부가항목(주소)',
  `WORK_FLAG` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N' COMMENT '작업여부 (Y: 완료, N: 미진행)',
  `WORK_DATE` datetime DEFAULT NULL COMMENT '작업완료 일자',
  `ERROR_FLAG` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N' COMMENT '에러여부 (Y: 에러, N: 에러아님)',
  `ERROR_MSG` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '에러 메세지',
  `ORDER_DATE` datetime NOT NULL COMMENT '정렬일자 (작업 순서)',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '업데이트 일자',
  `INSERT_DATE` datetime NOT NULL COMMENT '등록일자',
  PRIMARY KEY (`MSG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='SKT_CSPCON 연동 표준다운로드 : SSWG000002';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_dna_trait 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_dna_trait` (
  `CATEGORY` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '카테고리',
  `TRAIT_EN_NAME` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '트레잇 영문 이름',
  `TRAIT_KO_NAME` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '트레잇 한글 이름',
  `PERMITTIVITY` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '유전율',
  `RESULT_TYPE` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '결과 유형',
  `RESULT_DESC_UP` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '결과 설명 주의',
  `RESULT_INTERESTING` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '결과 설명 관심',
  `FOOD1` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '음식1',
  `SOLUTION1` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '솔루션1',
  `FOOD2` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '음식2',
  `SOLUTION2` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '솔루션2',
  `FOOD3` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '음식3',
  `SOLUTION3` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '솔루션3',
  `ITEM_DESC` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '아이템 설명',
  `NUTRIENT` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '영양',
  `PRECAUTION` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '주의 사항',
  `RELEASE_ORD` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '배포 순서',
  `PRIORITY1` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '우선순위1',
  `PRIORITY2` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '우선순위2',
  `ORDERBY` int(11) DEFAULT NULL COMMENT '정렬순서',
  PRIMARY KEY (`CATEGORY`,`TRAIT_EN_NAME`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_event 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_event` (
  `EVENT_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '이벤트 IDX',
  `TITLE` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '제목',
  `CONTENTS` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '내용',
  `EVENT_START_DATE` datetime DEFAULT NULL COMMENT '이벤트 시작일',
  `EVENT_END_DATE` datetime DEFAULT NULL COMMENT '이벤트 종료일',
  `IMG1_LINK` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '이미지 링크1',
  `IMG2_LINK` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '이미지 링크2',
  `IMG3_LINK` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '이미지 링크3',
  `BANNER_CLICK_CNT` int(11) DEFAULT NULL COMMENT '배너 클릭수',
  `IMG1_IDX` int(11) DEFAULT NULL COMMENT '이미지1 IDX',
  `IMG2_IDX` int(11) DEFAULT NULL COMMENT '이미지2 IDX',
  `IMG3_IDX` int(11) DEFAULT NULL COMMENT '이미지3 IDX',
  `POPUP_DISPLAY_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '팝업 보여주기 여부',
  `BANNER_FILE_IDX` int(11) NOT NULL COMMENT '배너 파일 IDX',
  `MAIN_FILE_IDX` int(11) DEFAULT NULL COMMENT '대표이미지',
  `DEL_YN` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N' COMMENT '삭제 여부',
  `MANAGER_IDX` int(11) DEFAULT NULL COMMENT '관리자 IDX',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '업데이트 날짜',
  `INSERT_DATE` datetime DEFAULT NULL COMMENT '인서트 날짜',
  PRIMARY KEY (`EVENT_IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_feed 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_feed` (
  `FEED_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '피드 IDX',
  `FEED_TYPE` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'BLOG: 블로그형\r\nCARDNEWS: 카드뉴스\r\nWEBTOON: 웹툽\r\nMOVIE: 동영상\r\nQUIZ: 퀴즈(2차)\r\nVOTE: 투표(2차)\r\nPICTURE: 틀린그림찾기(2차)',
  `START_DATE` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '시작 날짜',
  `CATEGORY` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '공통테이블 참조\r\nGENE_ITEM',
  `GENE_SPECIFIC` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'T_DNA_TRAIT 테이블 참조\r\nCATEGORY 에 따라 달라짐',
  `PERSONALITY` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'INFO_SEND:  정보전달\r\nGENER_ACTING: 행동유발\r\nFUNNY: 재미',
  `TITLE` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '제목',
  `CONTENTS` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '내용',
  `PREVIEW` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '미리보기',
  `READ_CNT` int(11) DEFAULT NULL COMMENT '읽기 수',
  `LIKE_CNT` int(11) DEFAULT NULL COMMENT '좋아요 수',
  `ORD` int(11) DEFAULT NULL COMMENT '슌서',
  `REPRESENT_IMG` int(11) DEFAULT NULL COMMENT '대표이미지',
  `TEMP_SAVE_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '등록 여부(Y:임시저장, N:등록)',
  `VIDEO_URL` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '비디오 URL',
  `UPPER_IMG` int(11) DEFAULT NULL COMMENT '상단이미지',
  `CONSULT_DISPLAY_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT '상담 보이기 여부',
  `MANAGER_IDX` int(11) NOT NULL COMMENT '관리자 IDX',
  `FILE_GROUP_IDX` int(11) NOT NULL COMMENT '파일 그룹 IDX',
  `UPDATE_DATE` datetime DEFAULT NULL,
  `INSERT_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`FEED_IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_feed_read_record 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_feed_read_record` (
  `FEED_IDX` int(11) DEFAULT NULL COMMENT '피드 IDX',
  `USER_IDX` int(11) DEFAULT NULL COMMENT '사용자 IDX',
  `INSERT_DATE` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='오늘 피드 읽은 사람 수';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_file 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_file` (
  `FILE_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '파일 IDX',
  `PART` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '파트',
  `FILENAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '파일이름',
  `EXT_NAME` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '확장자 이름',
  `FULLPATH_FILENAME` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '전체 파일 이름',
  `ACCESSIBLE_URL` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '접근 가능 URL',
  `INFO1` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '정보 1',
  `INFO2` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '정보2',
  `FILE_SIZE` int(11) DEFAULT NULL COMMENT '파일 사이즈',
  `THUMBNAIL_FILE_IDX` int(11) DEFAULT NULL COMMENT '섬네일 파일 IDX',
  `THUMBNAIL_YN` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '섬네일 YN',
  `ORIGIN_FILE_IDX` int(11) DEFAULT NULL COMMENT '오리지널 파일 IDX',
  `CHANGED_FILENAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '변경된 파일 이름',
  `DEL_YN` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '삭제 여부',
  `UPDATE_DATE` datetime DEFAULT NULL,
  `INSERT_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`FILE_IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=2009 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_file_group 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_file_group` (
  `FILE_GROUP_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '파일 그룹IDX',
  `FILE_IDX` int(11) NOT NULL COMMENT '파일 IDX',
  `FEED_CARD_ORD` int(11) DEFAULT NULL COMMENT '피드 카드 순서',
  PRIMARY KEY (`FILE_GROUP_IDX`,`FILE_IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=128 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_gene_function 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_gene_function` (
  `CATEGORY` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '카테고리',
  `ITEM` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ITEM',
  `GENE` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'GENE',
  `GENE_NICKNAME` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '닉네임',
  `DETAIL_RESULT` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '상세결과',
  `MY_GENE_FUNCTION` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '내 유전자 기능',
  `ORDERBY` int(11) NOT NULL COMMENT '유전자 정렬순서',
  PRIMARY KEY (`CATEGORY`,`ITEM`,`GENE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='유전자 기능';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_gene_trait 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_gene_trait` (
  `TRAIT` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `GENE` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SNP1_BAD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SNP1_NORMAL` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SNP1_GOOD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SNP2_BAD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SNP2_NORMAL` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SNP2_GOOD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SNP3_BAD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SNP3_NORMAL` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SNP3_GOOD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SNP4_BAD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SNP4_NORMAL` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `SNP4_GOOD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`TRAIT`,`GENE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='유전자 특성';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_korea_gene_avg 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_korea_gene_avg` (
  `TRAIT` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'TRAINT',
  `GENE` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'GENE',
  `SNP1_BAD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP1_나쁨',
  `SNP1_NORMAL` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP1_보통',
  `SNP1_GOOD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP1_좋음',
  `SNP2_BAD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP2_나쁨',
  `SNP2_NORMAL` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP2_보통',
  `SNP2_GOOD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP2_좋음',
  `SNP3_BAD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP3_나쁨',
  `SNP3_NORMAL` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP3_보통',
  `SNP3_GOOD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP3_좋음',
  `SNP4_BAD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP4_나쁨',
  `SNP4_NORMAL` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP4_보통',
  `SNP4_GOOD` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP4_좋음',
  `MAIL_AVG` double DEFAULT NULL COMMENT '남자평균',
  `FEMAIL_AVG` double DEFAULT NULL COMMENT '여자평균',
  PRIMARY KEY (`TRAIT`,`GENE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='한국인 유전자 평균';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_like 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_like` (
  `TBL_PK` int(11) DEFAULT NULL COMMENT '테이블 PK',
  `USER_IDX` int(11) DEFAULT NULL COMMENT '사용자 IDX'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_log_mid 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_log_mid` (
  `LOG_IDX` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '로그 IDX',
  `LOG_ID` char(32) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '로그 아이디',
  `LOG_ORDER` smallint(6) NOT NULL COMMENT '로그 순서 (로그 아이디 MAX)',
  `TRANS_TYPE` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '송수신여부 (SEND, RECV)',
  `REQUEST_URI` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '요청 URL',
  `REMOTE_ADDR` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '아이피',
  `METHOD` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '메소드',
  `BODY` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '데이터',
  `LOG_DATE` datetime NOT NULL COMMENT '로그일자',
  PRIMARY KEY (`LOG_IDX`),
  KEY `INDEX_LOG_MID` (`LOG_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=47220 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='TDNA_MID 서버 로그';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_macrogen_order 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_macrogen_order` (
  `SVC_MGMT_NUM` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'CSPCON 서비스관리번호',
  `PROD_ID` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'CSPCON 부가서비스ID',
  `REQUEST_DATE` datetime DEFAULT NULL COMMENT '요청일시',
  `CANCEL_DATE` datetime DEFAULT NULL COMMENT '취소일시',
  `ORDER_CODE` char(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '주문코드',
  `REQUEST_STATUS` char(2) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '요청상태',
  `CHARGE` char(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N' COMMENT '과금여부 (Y: 대상 5000원, N: 대상아님)',
  `CLIENT_KEY` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '고객 ID',
  `KITID` varchar(40) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Kit ID (리포트코드)',
  `ANALYSIS_RESULT` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '실험 성공 여부(success, fail)',
  `FAIL_COUNT` int(11) DEFAULT NULL COMMENT '실험 실패 횟수',
  `FAIL_MEMO` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '실험 실패 사유',
  `COMPLETE_DATE` datetime DEFAULT NULL COMMENT '실험 완료일자',
  `NOTE` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '비고',
  `GENDER` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '고객 성별',
  `BIRTH` int(11) DEFAULT NULL COMMENT '고객 생년월일',
  `NAME` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '고객 성명',
  `ADDRESS` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '고객 주소',
  `ZIPCODE` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '고객 우편번호',
  `CELLPHONE_NUMBER` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '고객 핸드폰번호',
  `PHONE_NUMBER` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '고객 집 전화번호',
  `DELIVERY_NOTE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '배송메모',
  `REQUEST_CATEGORY` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '사용자 구분',
  `METHOD` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '검사방법',
  `REPORTED_DATE` date DEFAULT NULL COMMENT '결과보고 날짜',
  `RECEIVED_DATE` date DEFAULT NULL COMMENT '검체접수 날짜',
  `SAMPLE_TYPE` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '검체의 출처 및 종류',
  `SAMPLE_SUITABILITY` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '검체적합성',
  `ANALYSIS_VERSION` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '버전',
  `PRIVACY_AGREE` char(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '개인정보동의여부 (Y: 동의, N: 미동의)',
  PRIMARY KEY (`ORDER_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Macrogen 연동 주문 정보';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_macrogen_order_kit 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_macrogen_order_kit` (
  `ORDER_CODE` char(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '주문코드',
  `INVOICE_TYPE` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'INVOICE 종류 (INVOICE1, INVOICE2)',
  `KIT_TYPE` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'KIT 종류(SEND, RECEIVE)',
  `COMPANY` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '키트발송 택배사',
  `NUMBER` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '키트발송 택배 송장번호',
  `DATETIME` datetime DEFAULT NULL COMMENT '키트발송 일시',
  `KIT_STATUS` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '키트발송 상태',
  PRIMARY KEY (`ORDER_CODE`,`INVOICE_TYPE`,`KIT_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Macrogen 연동 주문정보 : KIT';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_macrogen_order_trait 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_macrogen_order_trait` (
  `ORDER_CODE` char(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '주문코드',
  `TRAIT` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'TRAINT',
  `GRADE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'GRADE',
  `LESS_IS_BETTER` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'lessIsBetter (yes: 점수값이 낮을수록 좋음, no: 점수값이 높을수록 좋음, -: 긍정 또는 부정의 의미를 가지지 않음)',
  `SCORE` smallint(6) NOT NULL COMMENT '점수',
  `CATEGORY` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '카테고리 (인바이츠)',
  `RESULT_TYPE` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '결과 종류(POSITIVE: 긍정, USUALLY: 보통, DENIAL: 부정)',
  PRIMARY KEY (`ORDER_CODE`,`TRAIT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Macrogen 연동 주문정보 : TRAIT';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_macrogen_order_trait_gene 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_macrogen_order_trait_gene` (
  `ORDER_CODE` char(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '주문코드',
  `TRAIT` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'TRAINT',
  `GENE` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'GENE',
  `SNP1` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP1',
  `SNP2` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP2',
  `SNP3` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP3',
  `SNP4` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP4',
  `CATEGORY` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '카테고리 (인바이츠)',
  PRIMARY KEY (`ORDER_CODE`,`TRAIT`,`GENE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Macrogen 연동 주문정보 : TRAIT GENE + SNP';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_manager 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_manager` (
  `MANAGER_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '관리자 IDX',
  `MANAGER_GROUP_ID` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '관리자 그룹 ID',
  `ID` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ID',
  `STATUS` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'READY: 준비, NORMAL: 정상, EXPIRE: 탈퇴',
  `NAME` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '이름',
  `EMAIL` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'EMAIL',
  `NICKNAME` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '별명',
  `PASSWORD` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '패스워드',
  `TEL_NO` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '전화 번호',
  `PROFILE_IMAGE_IDX` int(11) DEFAULT NULL COMMENT '프로필IDX',
  `FIRST_LOGIN_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '최초 로그인 YN',
  `DEL_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT '삭제 여부',
  `UPDATE_DATE` datetime DEFAULT NULL,
  `INSERT_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`MANAGER_IDX`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_manager_group 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_manager_group` (
  `MANAGER_GROUP_ID` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '메니저 그룹 ID',
  `MANAGER_GROUP_NAME` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '메니지 그룹 이름',
  PRIMARY KEY (`MANAGER_GROUP_ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_menu 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_menu` (
  `MENU_ID` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '메뉴 ID',
  `MENU_NAME` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '메뉴 이름',
  `SUB_MENU_NAME` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '서브 메뉴 이름',
  `MENU_PATH` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '메뉴 PATH',
  PRIMARY KEY (`MENU_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_mtm_question 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_mtm_question` (
  `MTM_QUESTION_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '1:1 문의 IDX',
  `CATEGORY` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'MEMBER_Q: 회원문의\r\nGENE_INSPECTOR: 유전자 검사\r\nCOUPON: 상담 쿠폰\r\nSERVICE_ERROR: 서비스 오류\r\nETC: 기타',
  `USER_IDX` int(11) NOT NULL COMMENT '사용자 IDX',
  `TITLE` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '제목',
  `CONTENTS` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '내용',
  `STATUS` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'READY : 대기\r\nCOMPLETE: 완료',
  `ANSWER` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '답변',
  `MANAGER_IDX` int(11) DEFAULT NULL COMMENT '메니저 IDX',
  `ANSWER_INSERT_DATE` datetime DEFAULT NULL COMMENT '답변 시간',
  `A_FILE_GROUP_IDX` int(11) DEFAULT NULL COMMENT '질문 파일 그룹 IDX',
  `Q_FILE_GROUP_IDX` int(11) DEFAULT NULL COMMENT '다변 파일 그룹 IDX',
  `TEMP_SAVE_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '임시 저장 여부',
  `DEL_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT '삭제 여부',
  `UPDATE_DATE` datetime DEFAULT NULL,
  `INSERT_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`MTM_QUESTION_IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_notice 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_notice` (
  `NOTICE_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '공지사항 IDX',
  `TITLE` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '제목',
  `CONTENTS` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '내용',
  `POPUP_DISPLAY_YN` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '팝업 보이기 여부',
  `START_DAY` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '시작 날짜',
  `START_TIME` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '시작 시간',
  `IMAGE_FILE_IDX` int(11) NOT NULL COMMENT '이미지 파일 IDX',
  `DEL_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT '삭제 여부',
  `MANAGER_IDX` int(11) NOT NULL COMMENT '메니저 IDX',
  `UPDATE_DATE` datetime DEFAULT NULL,
  `INSERT_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`NOTICE_IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='공지사항';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_notification 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_notification` (
  `CATEGORY` varchar(10) DEFAULT NULL COMMENT '카테고리',
  `TYPE` varchar(30) DEFAULT NULL COMMENT '타입',
  `USER_IDX` int(11) DEFAULT NULL COMMENT '사용자 IDX',
  `TITLE` varchar(200) DEFAULT NULL COMMENT '제목',
  `CONTENTS` varchar(2000) DEFAULT NULL COMMENT '내용',
  `INSERT_DATE` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='알림 목록 리스트';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_reference 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_reference` (
  `ORD` int(1) DEFAULT NULL COMMENT '차수 ( 1차 개발, 2차 개발 )',
  `GENE` varchar(50) DEFAULT NULL COMMENT '유전자항목',
  `REFERENCE` varchar(200) DEFAULT NULL COMMENT '참고문헌'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='참고문헌';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_repeat_question 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_repeat_question` (
  `REPEAT_QUESTION_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '자주하는 질문 IDX',
  `CATEGORY` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'MEMBER:회원가입/수정/탈퇴,GENE:유전자검사,COUPON:상담/쿠폰,ETC:기타',
  `TITLE` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '제목',
  `CONTENTS` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '내용',
  `DISPLAY_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '보이기 여부',
  `MANAGER_IDX` int(11) NOT NULL COMMENT '메니저 IDX',
  `UPDATE_DATE` datetime DEFAULT NULL,
  `INSERT_DATE` datetime DEFAULT NULL,
  `DEL_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT '삭제 여부',
  PRIMARY KEY (`REPEAT_QUESTION_IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='자주하는 질문';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_reply 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_reply` (
  `REPLY_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '답변 IDX',
  `TYPE` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'FEED :피드\r\nCONSULT:상담',
  `BOARD_IDX` int(11) DEFAULT NULL COMMENT '보드 IDX',
  `COMMENT` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '상담:MAX 500자',
  `USER_IDX` int(11) DEFAULT NULL COMMENT '사용자 IDX',
  `MANAGER_IDX` int(11) DEFAULT NULL COMMENT '메니저 IDX',
  `DEL_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT '삭제 여부',
  `DELETE_MANAGER_IDX` int(11) DEFAULT NULL COMMENT '삭제 메니저 IDX',
  `MENTION_USER_IDX` int(11) DEFAULT NULL COMMENT '멘션 사용자 IDX',
  `MENTION_MANAGER_IDX` int(11) DEFAULT NULL COMMENT '멘션 관리자 IDX',
  `INSERT_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`REPLY_IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=90 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_resolve 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_resolve` (
  `RESOLVE_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '작심 7일 IDX',
  `MISSION_TYPE` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '미션 타입(상시:ALWAYS, 기간설정:CHOOSE)',
  `MISSION_START_DATE` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '미션 시작일(YYYY-MM-DD)',
  `MISSION_END_DATE` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '미션 종료일(YYYY-MM-DD)',
  `CATEGORY` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '종류(영양:NUTRIENT, 운동:SPORTS, 기타:ETC)',
  `TITLE` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '제목',
  `THUMBNAIL_FILE_IDX` int(11) DEFAULT NULL COMMENT '썸네일 이미지',
  `MISSION_FILE_IDX` int(11) DEFAULT NULL COMMENT '미션 상세 이미지',
  `CONTENTS` mediumtext COLLATE utf8mb4_unicode_ci COMMENT '내용',
  `BENEFIT` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '혜택',
  `BENEFIT_FILE_IDX` int(11) DEFAULT NULL COMMENT '혜택 이미지',
  `BANNER_FILE_IDX` int(11) DEFAULT NULL COMMENT '배너 이미지',
  `BANNER_LINK_URL` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '배너 링크 URL',
  `INSERT_DATE` datetime NOT NULL COMMENT '등록일',
  `UPDATE_DATE` datetime NOT NULL COMMENT '수정일',
  PRIMARY KEY (`RESOLVE_IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='작심 7일';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_resolve_diary 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_resolve_diary` (
  `DIARY_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '다이어리 IDX',
  `RESOLVE_IDX` int(11) NOT NULL COMMENT '작심 7일 IDX',
  `RESOLVE_MISSION_IDX` int(11) NOT NULL COMMENT '작심 7일 사용자 참가 미션IDX',
  `CONTENTS` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '내용( MAX 500자 )',
  `IMG_FILE_GROUP_IDX` int(11) DEFAULT '0' COMMENT '이미지 그룹 IDX',
  `DAY` int(1) NOT NULL DEFAULT '0' COMMENT '1 ~ 7( 1일차 ~ 7일차 )',
  `USER_IDX` int(11) NOT NULL COMMENT '사용자IDX',
  `INSERT_DATE` datetime NOT NULL COMMENT '등록일',
  `UPDATE_DATE` datetime NOT NULL COMMENT '수정일',
  PRIMARY KEY (`DIARY_IDX`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_resolve_mission 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_resolve_mission` (
  `RESOLVE_MISSION_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '작심 7일 사용자 참가 미션 IDX',
  `RESOLVE_IDX` int(11) NOT NULL COMMENT '작심 7일 IDX',
  `USER_IDX` int(11) NOT NULL COMMENT '사용자 IDX',
  `RESULT_STATUS` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '결과 상태(성공:SUCCESS, 진행:PROGRESS, 중단:STOP, 실패:FAIL)',
  `BENEFIT_STATUS` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N' COMMENT '혜택 상태(지급:Y, 미지급:N)',
  `DAY1` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N' COMMENT 'day1(default:N, 출석완료:Y)',
  `DAY2` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N' COMMENT 'day2(default:N, 출석완료:Y)',
  `DAY3` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N' COMMENT 'day3(default:N, 출석완료:Y)',
  `DAY4` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N' COMMENT 'day4(default:N, 출석완료:Y)',
  `DAY5` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N' COMMENT 'day5(default:N, 출석완료:Y)',
  `DAY6` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N' COMMENT 'day6(default:N, 출석완료:Y)',
  `DAY7` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'N' COMMENT 'day7(default:N, 출석완료:Y)',
  `JOIN_START_DATE` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '참여 시작일',
  `JOIN_END_DATE` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '참여 완료일',
  `INSERT_DATE` datetime DEFAULT NULL COMMENT '등록일',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '수정일',
  PRIMARY KEY (`RESOLVE_MISSION_IDX`) USING BTREE,
  KEY `RESOLVE_IDX` (`RESOLVE_IDX`) USING BTREE,
  KEY `USER_IDX` (`USER_IDX`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='작심 7일 미션';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_resolve_review 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_resolve_review` (
  `REVIEW_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '리뷰 IDX',
  `RESOLVE_IDX` int(11) NOT NULL COMMENT '작심 7일 IDX',
  `RESOLVE_MISSION_IDX` int(11) NOT NULL COMMENT '작심 7일 사용자 참가 미션IDX',
  `COMMENT` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '내용( MAX 500자 )',
  `USER_IDX` int(11) DEFAULT NULL COMMENT '사용자IDX',
  `DEL_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT '삭제 여부( 관리자가 삭제 했을 경우 )',
  `DELETE_MANAGER_IDX` int(11) DEFAULT NULL COMMENT '삭제한 관리자 IDX',
  `INSERT_DATE` datetime DEFAULT NULL COMMENT '등록일',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '수정일',
  PRIMARY KEY (`REVIEW_IDX`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_result_judgement 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_result_judgement` (
  `CATEGORY` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ITEM` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `LEVEL` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `MSG` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`CATEGORY`,`ITEM`,`LEVEL`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_scheduler 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_scheduler` (
  `SCHEDULER_IDX` int(11) NOT NULL COMMENT '스케줄러 IDX',
  `SCHEDULER_ID` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '스케줄 ID',
  `PERIOD` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '기간',
  `STATUS` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'A : 실행중\r\nB : 중단\r\nC : 정상 종료\r\nD : 비정상 종류',
  `START_TIME` datetime DEFAULT NULL COMMENT '시작시간',
  `END_TIME` datetime DEFAULT NULL COMMENT '끝난시간',
  `DESCRIPTION` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '설명',
  `DEL_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '삭제 여부',
  `ERR_MSG` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '에러 메시지',
  `JOB_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '잡 이름',
  PRIMARY KEY (`SCHEDULER_IDX`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_service 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_service` (
  `SERVICE_ID` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '서비스 ID',
  `USER_IDX` int(11) NOT NULL COMMENT '사용자 IDX',
  `TERMS_AGREE_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '이용약관 동의 여부',
  `RECV_EVENT_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '이벤트 수신 여부',
  `RECV_MAKETING_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '마켓팅 동의 여부',
  `RECV_INFO_YN` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y' COMMENT '정보 수신 동의 여부',
  PRIMARY KEY (`USER_IDX`,`SERVICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_service_type 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_service_type` (
  `SERVICE_ID` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'SERVICE_ID',
  `SERVICE_NAME` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '서비스 이름',
  `USE_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '서비스 사용유무',
  PRIMARY KEY (`SERVICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='서비스 종류';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_total_result 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_total_result` (
  `USER_IDX` int(11) NOT NULL COMMENT '사용자IDX',
  `CATEGORY` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '카테고리',
  `TRAIT` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '트레잇',
  `GENE` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'GENE',
  `SNP1` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP1',
  `SNP2` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP2',
  `SNP3` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP3',
  `SNP4` varchar(2) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNP4',
  `GRADE` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '등급',
  `LESS_IS_BETTER` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'lessIsBetter (yes: 점수값이 낮을수록 좋음, no: 점수값이 높을수록 좋음, -: 긍정 또는 부정의 의미를 가지지 않음)',
  `SCORE` float NOT NULL DEFAULT '0' COMMENT '점수',
  `RESULT_TYPE` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '결과 종류(POSITIVE: 긍정, USUALLY: 보통, DENIAL: 부정)',
  `SVC_MGMT_NUM` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '서비스 관리번호',
  `INSERT_DATE` datetime NOT NULL COMMENT '등록일자',
  PRIMARY KEY (`USER_IDX`,`CATEGORY`,`TRAIT`,`GENE`),
  KEY `INDEX_TOTAL_RESULT_SVC_MGMT_NUM` (`SVC_MGMT_NUM`),
  KEY `INDEX_TOTAL_RESULT_USER_IDX` (`USER_IDX`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='종합결과';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_user 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_user` (
  `USER_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '사용자 IDX',
  `USER_ID` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '아이디',
  `USER_NAME` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '이름',
  `USER_PASSWORD` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '패스워드',
  `USER_EMAIL` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '이메일',
  `USER_STATUS` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '상태 (NORMAL: 정상 \r\nDORMANT: 휴면\r\n탈퇴 - 회원정보가 삭제되어서 확인 불가)',
  `POST_NUMBER` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '우편번호',
  `USER_TYPE` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '사용자 구분',
  `USER_ADDR1` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '주소',
  `USER_ADDR2` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '상세주소',
  `USER_PHONE` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '전화번호',
  `USER_IMAGE_FILE_IDX` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '이미지 파일 IDX',
  `NICKNAME` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '닉네임',
  `USER_GENDER` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '성별',
  `USER_BIRTHDAY` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '생일',
  `SNS_TYPE` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNS 종류',
  `SNS_ID` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SNS ID',
  `DEL_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT '삭제여부',
  `TOKEN` varchar(4000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '로그인토큰',
  `SERIES_ID` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '시리얼 아이디',
  `LASTEST_LOGIN_DATE` datetime DEFAULT NULL COMMENT '마지막 로그인',
  `TDNA_ADD_STATUS` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '부가서비스 가입상태 (READY: 대기\r\nSIGNIN: 가입\r\nRETIRE: 해지)',
  `TDNA_INSPECTION_STATUS` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '검사현황 (KIT_SEND: KIT 발송\r\nKIT_RECV: KIT 접수\r\nRESULT_SUPPLY: 결과제공)',
  `KIT_RECV_DATE` datetime DEFAULT NULL COMMENT '키트접수 일자',
  `KIT_NUMBER` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '키트 번호',
  `BADGE_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'BADGE_YN',
  `AUTH_SMS` varchar(6) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'SMS 인증여부',
  `CONSULT_AGREE_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT '상담 정보제공 동의여부 YN',
  `ANALYSIS_RESULT_YN` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT '피드 ''검사 안내'' 확인여부 YN',
  `SKT_USER` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT 'N' COMMENT 'SKT 사용자',
  `SVC_MGMT_NUM` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'CSP 서비스관리번호',
  `USER_SIGNUP_DATE` datetime DEFAULT NULL COMMENT '회원 가입일',
  `USER_EXPIRE_DATE` datetime DEFAULT NULL COMMENT '회원 탈퇴일',
  `SERVICE_SIGNUP_DATE` datetime DEFAULT NULL COMMENT '부가서비스 가입일',
  `SERVICE_EXPIRE_DATE` datetime DEFAULT NULL COMMENT '부가서비스 해지일',
  `TEMP_SERVICE_SIGNUP_DATE` datetime DEFAULT NULL COMMENT '임시상품 가입 날짜',
  `REAL_SERVICE_SIGNUP_DATE` datetime DEFAULT NULL COMMENT '본상품 가입 날짜',
  `UPDATE_MANAGER_IDX` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '변경 담당자 IDX',
  `FCM_TOKEN` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'FCM_TOKEN',
  `UPDATE_DATE` datetime DEFAULT NULL COMMENT '변경일자',
  `INSERT_DATE` datetime DEFAULT NULL COMMENT '등록일자',
  PRIMARY KEY (`USER_IDX`),
  UNIQUE KEY `USER_ID` (`USER_ID`),
  UNIQUE KEY `NICKNAME` (`NICKNAME`),
  KEY `INDEX_USER_SVC_MGMT_NUM` (`SVC_MGMT_NUM`)
) ENGINE=InnoDB AUTO_INCREMENT=754 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='사용자';

-- 내보낼 데이터가 선택되어 있지 않습니다.

-- 테이블 care8-prod.t_version 구조 내보내기
CREATE TABLE IF NOT EXISTS `t_version` (
  `VERSION_IDX` int(11) NOT NULL AUTO_INCREMENT COMMENT '버전 IDX',
  `OS_TYPE` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'A: 안드로이드 I:IOS',
  `VERSION1` int(11) DEFAULT NULL COMMENT '버전1',
  `VERSION2` int(11) DEFAULT NULL COMMENT '버전2',
  `VERSION3` int(11) DEFAULT NULL COMMENT '버전3',
  `REQUIRE_YN` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '필수 여부',
  `MEMO` varchar(2000) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '메모',
  `DEPLOY_DATE` datetime DEFAULT NULL COMMENT '배포 날짜',
  `UPDATE_MANAGER_IDX` int(11) DEFAULT NULL COMMENT '관리자 IDX',
  `UPDATE_DATE` datetime DEFAULT NULL,
  `INSERT_DATE` datetime DEFAULT NULL,
  PRIMARY KEY (`VERSION_IDX`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
